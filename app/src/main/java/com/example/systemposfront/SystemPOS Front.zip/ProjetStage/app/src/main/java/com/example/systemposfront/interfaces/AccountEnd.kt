package com.example.systemposfront.interfaces

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


interface AccountEnd {


    var BASE_URL: String
        get() = "http://192.168.86.1:8080"
        set(value) = TODO()

    var retrofit: Retrofit
        get() = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        set(value) = TODO()


}