package com.example.systemposfront.bo

abstract class Person {


    private var id: Long? = null

    private var firstName: String? = null

    private var lastName: String? = null

    private var numTel: String? = null
    private var urlImage: String? = null
}