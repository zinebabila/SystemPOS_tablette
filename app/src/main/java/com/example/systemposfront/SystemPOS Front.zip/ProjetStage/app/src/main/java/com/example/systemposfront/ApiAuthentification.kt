package com.example.systemposfront

import com.oreilly.servlet.multipart.Base64Encoder
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class ApiAuthentification{
    private var baseUrl: String? = null
    private var login: String? = null
    private var password: String? = null
    private var urlResource: String? = null
    private var httpMethod: String? = null
    private var urlPath: String? = null
    private var lastResponse: String? = null
    private var payload: String? = null
    private var parameters: HashMap<String, String>? = null
    private var headerFields: HashMap<String, List<String>>? = null


    fun ApiAuthentification(baseUrl: String, login: String?, password: String?) {
        setBaseUrl(baseUrl)
        this.login = login
        this.password = password
        urlResource = ""
        urlPath = ""
        httpMethod = "GET"
        parameters = HashMap()
        lastResponse = ""
        payload =""
        headerFields = HashMap()
       // System.setProperties("jsse.enableSNIExtension", "false");


    }

    fun setBaseUrl(baseUr: String): ApiAuthentification? {
        baseUrl = baseUr
        if (baseUr.substring(baseUr.length - 1) != "/") {
            baseUrl += "/"
        }
        return this
    }
    fun setUrlResource(urlResourc :String):ApiAuthentification?{
      urlResource=urlResourc
      return  this
    }
    final fun  setPath(urlpath :String):ApiAuthentification?{
        urlPath=urlpath
        return  this
    }
    final fun  setHttpMethod(httpm :String):ApiAuthentification?{
        httpMethod=httpm
        return  this
    }
    fun getLastResponse():String?{
        return lastResponse
    }
    fun getHeaderFields():Map<String,List<String>>?{
        return headerFields
    }
    fun setParameters(parametr:HashMap<String,String>):ApiAuthentification?{
        parameters=parametr
        return  this
    }
    fun setParameter(key:String,value:String):ApiAuthentification?{
        parameters?.put(key,value)
        return  this
    }
    fun clearParameters():ApiAuthentification?{
        parameters?.clear();
        return this
    }
    fun removeParametre(key:String):ApiAuthentification?{
        parameters?.remove(key)
       return  this
    }
    fun clearAll():ApiAuthentification?{
        parameters?.clear()
        baseUrl =""
        login=""
        password =""
        urlResource=""
        urlPath=""
        httpMethod=""
        lastResponse=""
        payload=""
        headerFields?.clear()
        return this
    }
    fun getLastResponseAsJsonObject(): JSONObject? {
        try {
            return JSONObject(lastResponse.toString())
        } catch (e: JSONException) {
            e.printStackTrace()
        }
        return null
    }
    fun getLastResponseAsJsonArray(): JSONArray? {
        try {
            return JSONArray(lastResponse.toString())
        } catch (e: JSONException) {
            e.printStackTrace()
        }
        return null
    }
    private fun getPayloadAsString(): String? {
// Cycle through the parameters.
        val stringBuffer = StringBuilder()
        val it: MutableIterator<*> = parameters!!.entries.iterator()
        var count = 0
        while (it.hasNext()) {
            val (key, value) = it.next() as Map.Entry<*, *>
            if (count > 0) {
                stringBuffer.append("&")
            }
            stringBuffer.append(key).append("=").append(value)
            it.remove() // avoids a ConcurrentModificationException
            count++
        }
        return stringBuffer.toString()
    }
    fun execute(): String? {
        var line: String?
        val outputStringBuilder = java.lang.StringBuilder()
        try {
            val urlString = java.lang.StringBuilder(baseUrl + urlResource)
            if (urlPath != "") {
                urlString.append("/$urlPath")
            }
            if (parameters!!.size > 0 && httpMethod == "GET") {
                payload = getPayloadAsString()
                urlString.append("?$payload")
            }
            val url = URL(urlString.toString())
            val encoding: String = Base64Encoder.encode(login + ":" + password)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = httpMethod
            connection.setRequestProperty("Authorization", "Basic $encoding")
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("Content-Type", "text/plain")

            // Make the network connection and retrieve the output from the server.
            if (httpMethod == "POST" || httpMethod == "PUT") {
                payload = getPayloadAsString()
                connection.doInput = true
                connection.doOutput = true
                try {
                    val writer = OutputStreamWriter(connection.outputStream, "UTF-8")
                    writer.write(payload)
                    headerFields = connection.headerFields as HashMap<String, List<String>>?
                    val br = BufferedReader(InputStreamReader(connection.inputStream))
                    while (br.readLine().also { line = it } != null) {
                        outputStringBuilder.append(line)
                    }
                } catch (ex: Exception) {
                }
                connection.disconnect()
            } else {
                val content = connection.inputStream as InputStream
                headerFields = connection.headerFields as HashMap<String, List<String>>?

                //connection.
                val `in` = BufferedReader(InputStreamReader(content))
                while (`in`.readLine().also { line = it } != null) {
                    outputStringBuilder.append(line)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // If the outputStringBuilder is blank, the call failed.
        if (outputStringBuilder.toString() != "") {
            lastResponse = outputStringBuilder.toString()
        }
        return outputStringBuilder.toString()
    }

}



