package com.example.systemposfront.bo

class Payment {

    private var id: Long? = null
    private var somme: Double? = null

    private var customer: Customer? = null

    private var currency: Currency? = null

    private var command: Command? = null
}