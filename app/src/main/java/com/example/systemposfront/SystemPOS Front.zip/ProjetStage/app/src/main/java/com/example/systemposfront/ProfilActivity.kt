package com.example.systemposfront

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ProfilActivity: AppCompatActivity() {
    private var textView :TextView? =null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profil)
    textView=findViewById(R.id.emailTv) as TextView
        var bundl: Bundle? =intent.extras
        if (bundl != null) {
            textView!!.text=bundl.getString("username").toString()

        }

    }
}