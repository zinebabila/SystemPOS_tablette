package com.example.systemposfront.bo

import kotlinx.serialization.Serializable

@Serializable
class Account {

     val id: Long? = null

     var email: String? = null

     var password: String? = null

     var type = 0.toChar()

     val commands: Set<Command?>? = null

     val merchantCreator: Merchant? = null

     val merchantOwner: Merchant? = null
}