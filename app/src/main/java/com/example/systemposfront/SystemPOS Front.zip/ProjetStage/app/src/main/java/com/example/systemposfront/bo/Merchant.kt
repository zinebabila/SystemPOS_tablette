package com.example.systemposfront.bo

class Merchant {
    private var sold: Double? = null

    private var account: Account? = null

    private var reviews: Set<Review> = HashSet()


    private var accountsCreated: Set<Account> = HashSet()


    private var coupons: Set<Coupon> = HashSet()


    private var notifications: Set<Notification> = HashSet()


    private var currencies: Set<Currency> = HashSet()


    private var products: Set<Product> = HashSet()

}