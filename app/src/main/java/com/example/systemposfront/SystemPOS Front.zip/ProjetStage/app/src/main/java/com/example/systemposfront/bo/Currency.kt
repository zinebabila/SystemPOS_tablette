package com.example.systemposfront.bo

class Currency {


    private var id: Long? = null

    private var currencyName: String? = null
    private var percentageToDollar: Double? = null

    private var payments: Set<Payment?> = HashSet()

    private var merchants: Set<Merchant?> = HashSet()
}