package com.example.systemposfront.bo

import java.util.*

class Coupon {


    private var id: Long? = null

    private var code: String? = null
    private var reduction: Double? = null
    private var expirationDate: Date? = null

    private var merchantCreatorCoupon: Merchant? = null

    private var commands: Set<Command?> = HashSet()
}