package com.example.systemposfront.bo

class Product {
    private var id: Long? = null

    private var title: String? = null

    private var description: String? = null
    private var reduction: Double? = null
    private var qteStock = 0

    private var images: Set<ImageProducts> = HashSet()


    private var category: Category? = null

    private var commandLigne: CommandLine? = null

    private var merchant: Merchant? = null


}