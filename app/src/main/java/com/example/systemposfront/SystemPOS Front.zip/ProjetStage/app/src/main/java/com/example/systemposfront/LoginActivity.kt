package com.example.systemposfront

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.systemposfront.bo.Account
import com.example.systemposfront.controller.AccountController


import retrofit2.Call
import java.util.regex.Pattern


class LoginActivity : AppCompatActivity() {
    private var button_login_login: Button? = null
    private var editText_login_username: EditText? = null
    private var editText_login_password: EditText? = null
    private var singupbtn:Button?=null
    private var username: String? = null
    private var password: String? = null
    private var baseUrl: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
         baseUrl=" ********* "
        editText_login_password=findViewById(R.id.password) as EditText
        editText_login_username=findViewById(R.id.email)as EditText
        button_login_login=findViewById(R.id.loginbtn) as Button
        singupbtn=findViewById(R.id.Signbtn) as Button
        singupbtn!!.setOnClickListener(object : View.OnClickListener{
            override fun onClick(view: View?) {
               goToSingUpActivity()
            }

        })

        button_login_login!!.setOnClickListener(object : View.OnClickListener {

            @SuppressLint("ResourceAsColor")
            override fun onClick(view: View?) {

                if(CheckAllFields(editText_login_password!!,
                        editText_login_password!!
                    )){
                    username = editText_login_username!!.getText().toString()
                    password = editText_login_password!!.getText().toString()
                    var loginRegistration: Account = setLoginRegistrationData()
                    var registrationEndPoint: Call<Account> = AccountController.create().putNewDataOnDb(loginRegistration)
                   println(registrationEndPoint.isExecuted.toString() + "******************************")

                     goToSecondActivity()}
   else{
       if(!editText_login_username!!.isEmailValid())
       editText_login_username!!.error=getString(R.string.error)

     //  editText_login_password!!.backgroundTintList= resources.getColor(R.color.red)
                }

                               }

        })



}

    private fun setLoginRegistrationData(): Account {
var account=Account()
account.email=username;
        account.password=password
        account.type='M'
        return account

    }

    private fun goToSingUpActivity() {
        val intent = Intent(this, SingUpMerchant::class.java)

        startActivity(intent)
    }
    private fun goToSecondActivity() {
        val bundle = Bundle()
        bundle.putString("username", username)
        bundle.putString("password", password)
        bundle.putString("baseUrl", baseUrl)
        val intent = Intent(this, ProfilActivity::class.java)
        intent.putExtras(bundle)
        startActivity(intent)
    }
    fun TextView.isEmailValid(): Boolean {
        val expression = "^[\\w.-]+@([\\w\\-]+\\.)+[A-Z]{2,8}$"
        val pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE)
        val matcher = pattern.matcher(this.text)
        return matcher.matches()
    }

    private fun CheckAllFields(etPassword: TextView, etEmail: TextView): Boolean {
        if (etEmail.length() == 0) {
            etEmail.error = "Email is required"
            return false
        }
        if (etPassword.length() == 0) {
            etPassword.error = "Password is required"
            return false
        }
        return true
    }
}

