package com.example.systemposfront.bo

class Category {
    private var id: Long? = null

    private var nameCategory: String? = null


    private var products: Set<Product> = HashSet()


}