package com.example.systemposfront.bo

import java.sql.Date
import java.util.*

class Command {
    private var id: Long? = null

    private var dateCommand: java.util.Date = Date(Date().time)
    private var account: Account? = null

    private var coupon: Coupon? = null

    private var commandLignes: Set<CommandLine?> = HashSet()

    private var payments: Set<Payment?> = HashSet()
}