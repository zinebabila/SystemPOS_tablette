package com.example.systemposfront.controller

import com.example.systemposfront.bo.Account

import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body

import retrofit2.http.POST

interface AccountController {

    @POST("/Account")
   fun putNewDataOnDb(@Body account: Account):Call<Account>

    companion object {

        var BASE_URL = "http://127.0.0.1:8080"

        fun create() : AccountController {

            val retrofit = Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl(BASE_URL)
                .build()
            return retrofit.create(AccountController::class.java)

        }
    }

}