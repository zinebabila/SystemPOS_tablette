package com.example.systemposfront.bo

class Notification {


    private var id: Long? = null
    private var description: String? = null
    private var merchant: Merchant? = null
}