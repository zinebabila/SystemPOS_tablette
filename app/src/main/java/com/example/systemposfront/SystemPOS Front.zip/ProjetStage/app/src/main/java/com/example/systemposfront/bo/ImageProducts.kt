package com.example.systemposfront.bo

class ImageProducts {
    private var id: Long? = null

    private var urlImage: String? = null
    private var product: Product? = null
}