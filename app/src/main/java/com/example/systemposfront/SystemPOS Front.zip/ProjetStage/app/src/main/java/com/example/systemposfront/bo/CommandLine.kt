package com.example.systemposfront.bo

class CommandLine {
    private var id: Long? = null
    private var qte = 0

    private var product: Product? = null

    private var command: Command? = null


}