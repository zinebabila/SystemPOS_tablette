package com.example.systemposfront.bo

class Customer {
    private var reviews: Set<Review> = HashSet()

    private var payments: Set<Payment> = HashSet()


}